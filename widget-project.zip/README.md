# My Widget Project

## Description
Un widget interactif simple pour afficher des faits rapides, des flashcards, et plus.

## Installation
1. Clonez ce dépôt :
   ```
   git clone https://github.com/votre-utilisateur/widget-project.git
   ```
2. Ouvrez `index.html` dans votre navigateur.

## Contribuer
1. Fork le projet.
2. Créez une nouvelle branche.
3. Faites vos modifications et créez une Pull Request.

## License
MIT License
