document.getElementById("my-widget").innerHTML = `
  <div>
    <h3 style="color: #ff4500;">Daily Learning</h3>
    <button onclick="alert('Quick Fact!')">Show Fact</button>
  </div>
`;
